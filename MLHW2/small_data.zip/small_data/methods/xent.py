import torch
from torch import nn
from typing import Tuple, Callable, Optional, Union

from .common import BasicAugmentation


class CrossEntropyClassifier(BasicAugmentation):
    """ Standard cross-entropy classification as baseline.

    See `BasicAugmentation` for a documentation of the available hyper-parameters.
    """


    @staticmethod
    def default_hparams() -> dict:
      return {
        **super(CrossEntropyClassifier, CrossEntropyClassifier).default_hparams(),
        'lr_decay' : 0.002
      }

    def get_loss_function(self) -> Callable:

        return nn.CrossEntropyLoss(reduction='mean')



    def get_optimizer(self, model: nn.Module, max_epochs: int, max_iter: int) -> Tuple[torch.optim.Optimizer, torch.optim.lr_scheduler._LRScheduler]:
        """ Instantiates an optimizer and learning rate schedule.

        Parameters
        ----------
        model : nn.Module
            The model to be trained.
        max_epochs : int
            The total number of epochs.
        max_iter : int
            The total number of iterations (epochs * batches_per_epoch).
        
        Returns
        -------
        optimizer : torch.optim.Optimizer
        lr_schedule : torch.optim.lr_scheduler._LRScheduler
        """
        optimizer = torch.optim.Adagrad(model.parameters(), lr=self.hparams['lr'], weight_decay=self.hparams['weight_decay'], lr_decay = self.hparams['lr_decay'])
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max_iter)

        return optimizer, scheduler





